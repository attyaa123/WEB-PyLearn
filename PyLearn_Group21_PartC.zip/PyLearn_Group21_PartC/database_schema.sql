CREATE DATABASE IF NOT EXISTS pylearn_db;
USE pylearn_db;

CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  email VARCHAR(255) NOT NULL UNIQUE,
  -- Stores a bcrypt hash, not the plain password.
  password VARCHAR(255) NOT NULL,
  xp INT DEFAULT 0,
  level INT DEFAULT 1,
  streak INT DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS stages (
  id VARCHAR(50) PRIMARY KEY,
  stage_number INT NOT NULL UNIQUE,
  title VARCHAR(100) NOT NULL
);

CREATE TABLE IF NOT EXISTS questions (
  id VARCHAR(20) PRIMARY KEY,
  source_question_id INT NOT NULL UNIQUE,
  stage_id VARCHAR(50) NOT NULL,
  topic VARCHAR(100) NOT NULL,
  difficulty VARCHAR(20) NOT NULL,
  xp_reward INT NOT NULL,
  prompt TEXT NOT NULL,
  option_a TEXT NOT NULL,
  option_b TEXT NOT NULL,
  option_c TEXT NOT NULL,
  option_d TEXT NOT NULL,
  correct_answer_index INT NOT NULL,
  explanation TEXT NOT NULL,
  FOREIGN KEY (stage_id) REFERENCES stages(id)
);

CREATE TABLE IF NOT EXISTS user_progress (
  user_id INT PRIMARY KEY,
  progress_json JSON NOT NULL,
  selected_stage_id VARCHAR(50) DEFAULT 'basics',
  last_active_date DATE NULL,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS user_answers (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  question_id VARCHAR(20) NOT NULL,
  selected_index INT NOT NULL,
  is_correct BOOLEAN NOT NULL,
  xp_awarded INT NOT NULL DEFAULT 0,
  answered_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY unique_user_question (user_id, question_id),
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (question_id) REFERENCES questions(id)
);
