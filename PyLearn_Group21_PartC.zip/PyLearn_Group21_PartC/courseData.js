const rawQuestions = require("./python_quiz_questions.json");

const COURSE_STAGES = [
  { id: "basics", number: 1, title: "Python Basics" },
  { id: "variables", number: 2, title: "Variables" },
  { id: "conditions", number: 3, title: "Conditions" },
  { id: "loops", number: 4, title: "Loops" },
  { id: "functions", number: 5, title: "Functions" }
];

const OPTION_LETTERS = ["A", "B", "C", "D"];
const DIFFICULTY_BY_LEVEL = { 1: "Easy", 2: "Medium", 3: "Hard" };
const XP_BY_LEVEL = { 1: 5, 2: 10, 3: 15 };

const STAGE_BY_QUESTION_ID = {
  1: "basics",
  2: "basics",
  3: "functions",
  4: "variables",
  5: "variables",
  6: "variables",
  7: "conditions",
  8: "basics",
  9: "variables",
  10: "basics",
  11: "loops",
  12: "variables",
  13: "conditions",
  14: "variables",
  15: "variables",
  16: "loops",
  17: "variables",
  18: "variables",
  19: "variables",
  20: "functions",
  21: "basics",
  22: "loops",
  23: "loops",
  24: "functions",
  25: "functions",
  26: "loops",
  27: "functions",
  28: "functions",
  29: "conditions",
  30: "functions"
};

const TOPIC_BY_QUESTION_ID = {
  1: "Modulo and arithmetic",
  2: "Indentation",
  3: "Function definitions",
  4: "List indexing",
  5: "String indexing",
  6: "List append",
  7: "if / else",
  8: "Comparison operators",
  9: "List syntax",
  10: "Floor division",
  11: "Reversed iteration",
  12: "List references",
  13: "filter() and truthy values",
  14: "Lists and tuples",
  15: "String methods",
  16: "List comprehensions",
  17: "Dictionaries",
  18: "Dictionary access",
  19: "Dictionary methods",
  20: "Function scope",
  21: "Exponentiation",
  22: "Shallow copy",
  23: "Nested lists",
  24: "Lambda functions",
  25: "map()",
  26: "map/filter/reduce",
  27: "*args and **kwargs",
  28: "Recursion",
  29: "Exceptions",
  30: "Classes and objects"
};

const QUESTION_BANK = rawQuestions.map((question) => ({
  id: `q${question.question_id}`,
  sourceQuestionId: question.question_id,
  stageId: STAGE_BY_QUESTION_ID[question.question_id],
  topic: TOPIC_BY_QUESTION_ID[question.question_id],
  difficulty: DIFFICULTY_BY_LEVEL[question.level],
  xpReward: XP_BY_LEVEL[question.level],
  prompt: question.question_text,
  options: OPTION_LETTERS.map((letter) => question.options[letter]),
  correctAnswer: OPTION_LETTERS.indexOf(question.correct_answer),
  explanation: question.explanation
}));

function calculateLevel(xp) {
  return Math.floor(Math.max(0, Number(xp) || 0) / 20) + 1;
}

function getQuestionById(questionId) {
  return QUESTION_BANK.find((question) => question.id === questionId) || null;
}

module.exports = {
  COURSE_STAGES,
  QUESTION_BANK,
  calculateLevel,
  getQuestionById
};
