const express = require("express");
const bodyParser = require("body-parser");
const session = require("express-session");
const bcrypt = require("bcryptjs");
const path = require("path");
const db = require("./db");
const { COURSE_STAGES, QUESTION_BANK, calculateLevel, getQuestionById } = require("./courseData");

const app = express();
const dbPromise = db.promise();
const port = process.env.PORT || 3000;
const dbName = process.env.DB_NAME || "pylearn_db";
const emailPattern = /^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$/;
const passwordHashPattern = /^\$2[aby]\$/;

app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.use(session({
  secret: process.env.SESSION_SECRET || "pylearn-local-session-secret",
  resave: false,
  saveUninitialized: false,
  cookie: {
    httpOnly: true,
    sameSite: "lax",
    secure: false
  }
}));

app.use("/css", express.static(path.join(__dirname, "css")));
app.use("/js", express.static(path.join(__dirname, "js")));
app.use("/images", express.static(path.join(__dirname, "images")));

function escapeIdentifier(identifier) {
  if (!/^[A-Za-z0-9_]+$/.test(identifier)) {
    throw new Error("DB_NAME may contain only letters, numbers, and underscores.");
  }

  return `\`${identifier}\``;
}

function getDisplayName(email) {
  return email
    .split("@")[0]
    .replace(/[._-]+/g, " ")
    .split(" ")
    .filter(Boolean)
    .map((part) => part.charAt(0).toUpperCase() + part.slice(1))
    .join(" ");
}

function validateLoginInput(email, password) {
  const errors = [];

  if (!email) {
    errors.push("Email is required.");
  } else if (!emailPattern.test(email)) {
    errors.push("Please enter a valid email address.");
  }

  if (!password) {
    errors.push("Password is required.");
  } else if (password.length < 6) {
    errors.push("Password must be at least 6 characters long.");
  }

  return errors;
}

function getLocalDateString(date = new Date()) {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");
  return `${year}-${month}-${day}`;
}

function parseProgress(progressJson) {
  if (!progressJson) {
    return null;
  }

  if (typeof progressJson === "object") {
    return progressJson;
  }

  try {
    return JSON.parse(progressJson);
  } catch (error) {
    return null;
  }
}

function validateUserId(userId) {
  const numericUserId = Number(userId);
  return Number.isInteger(numericUserId) && numericUserId > 0 ? numericUserId : null;
}

function toIsoString(value) {
  if (!value) {
    return new Date().toISOString();
  }

  if (value instanceof Date) {
    return value.toISOString();
  }

  return String(value);
}

function formatDateValue(value) {
  if (!value) {
    return "";
  }

  if (value instanceof Date) {
    return getLocalDateString(value);
  }

  return String(value).slice(0, 10);
}

function createStageProgress() {
  return COURSE_STAGES.reduce((stages, stage) => {
    stages[stage.id] = {
      unlocked: false,
      completed: false,
      answeredQuestions: {}
    };
    return stages;
  }, {});
}

function createDefaultProgress() {
  return {
    totalXP: 0,
    xp: 0,
    level: 1,
    streak: 0,
    lastActiveDate: "",
    selectedStageId: "basics",
    selectedStage: 1,
    earnedQuestionIds: [],
    currentQuestionByStage: {},
    stages: createStageProgress()
  };
}

function getStageById(stageId) {
  return COURSE_STAGES.find((stage) => stage.id === stageId || stage.number === Number(stageId))
    || COURSE_STAGES[0];
}

function getQuestionsForStage(stageId) {
  return QUESTION_BANK.filter((question) => question.stageId === stageId);
}

function clamp(value, min, max) {
  return Math.min(Math.max(value, min), max);
}

function recalculateStageLocks(progress) {
  let previousPlayableCompleted = true;

  COURSE_STAGES.forEach((stage) => {
    const stageProgress = progress.stages[stage.id];
    const stageQuestions = getQuestionsForStage(stage.id);
    const totalQuestions = stageQuestions.length;
    const answeredCount = stageQuestions.filter((question) => {
      return Boolean(stageProgress.answeredQuestions[question.id]);
    }).length;

    stageProgress.completed = totalQuestions > 0 && answeredCount === totalQuestions;
    stageProgress.unlocked = totalQuestions > 0 && previousPlayableCompleted;

    if (totalQuestions > 0) {
      previousPlayableCompleted = stageProgress.completed;
    }
  });

  return progress;
}

function getFirstUnlockedPlayableStageId(progress) {
  const unlockedIncomplete = COURSE_STAGES.find((stage) => {
    const stageProgress = progress.stages[stage.id];
    const hasQuestions = getQuestionsForStage(stage.id).length > 0;
    return hasQuestions && stageProgress.unlocked && !stageProgress.completed;
  });

  if (unlockedIncomplete) {
    return unlockedIncomplete.id;
  }

  const unlockedPlayable = COURSE_STAGES.find((stage) => {
    const stageProgress = progress.stages[stage.id];
    const hasQuestions = getQuestionsForStage(stage.id).length > 0;
    return hasQuestions && stageProgress.unlocked;
  });

  return unlockedPlayable ? unlockedPlayable.id : "basics";
}

function sanitizeCurrentQuestionByStage(value) {
  const source = value && typeof value === "object" ? value : {};
  const currentQuestionByStage = {};

  COURSE_STAGES.forEach((stage) => {
    const questionCount = getQuestionsForStage(stage.id).length;
    const index = Number(source[stage.id]);
    currentQuestionByStage[stage.id] = questionCount > 0
      ? clamp(Number.isFinite(index) ? index : 0, 0, questionCount - 1)
      : 0;
  });

  return currentQuestionByStage;
}

function sanitizePracticeState(value) {
  const source = value && typeof value === "object" ? value : {};
  const practiceResets = {};
  const practiceAnswers = {};

  if (source.practiceResets && typeof source.practiceResets === "object") {
    COURSE_STAGES.forEach((stage) => {
      const resetAt = source.practiceResets[stage.id];

      if (typeof resetAt === "string" && !Number.isNaN(Date.parse(resetAt))) {
        practiceResets[stage.id] = resetAt;
      }
    });
  }

  if (source.practiceAnswers && typeof source.practiceAnswers === "object") {
    COURSE_STAGES.forEach((stage) => {
      const stageAnswers = source.practiceAnswers[stage.id];

      if (!stageAnswers || typeof stageAnswers !== "object") {
        return;
      }

      practiceAnswers[stage.id] = {};

      getQuestionsForStage(stage.id).forEach((question) => {
        const answerState = stageAnswers[question.id];
        const selectedIndex = answerState && Number(answerState.selectedIndex);

        if (!Number.isInteger(selectedIndex) || selectedIndex < 0 || selectedIndex > 3) {
          return;
        }

        const status = selectedIndex === question.correctAnswer ? "correct" : "incorrect";
        practiceAnswers[stage.id][question.id] = {
          status,
          selectedIndex,
          firstAttemptCorrect: status === "correct",
          xpAwarded: false,
          practice: true,
          answeredAt: typeof answerState.answeredAt === "string"
            ? answerState.answeredAt
            : new Date().toISOString()
        };
      });
    });
  }

  return { practiceResets, practiceAnswers };
}

function shouldHideStoredAnswerForPractice(question, answer, practiceResets) {
  const resetAt = practiceResets[question.stageId];

  if (!resetAt) {
    return false;
  }

  return new Date(answer.answered_at).getTime() <= new Date(resetAt).getTime();
}

function getSafeSelectedStageId(stageId, progress) {
  const normalizedStage = getStageById(stageId);
  const stats = progress.stages[normalizedStage.id];
  const hasQuestions = getQuestionsForStage(normalizedStage.id).length > 0;

  return hasQuestions && stats && stats.unlocked
    ? normalizedStage.id
    : getFirstUnlockedPlayableStageId(progress);
}

function getPublicUser(user) {
  return {
    id: user.id,
    email: user.email,
    name: getDisplayName(user.email),
    xp: Number(user.xp) || 0,
    level: Number(user.level) || 1,
    streak: Number(user.streak) || 0
  };
}

async function initializeDatabase() {
  const escapedDbName = escapeIdentifier(dbName);

  await dbPromise.query(`CREATE DATABASE IF NOT EXISTS ${escapedDbName}`);
  await dbPromise.query(`USE ${escapedDbName}`);

  await dbPromise.query(`
    CREATE TABLE IF NOT EXISTS users (
      id INT AUTO_INCREMENT PRIMARY KEY,
      email VARCHAR(255) NOT NULL UNIQUE,
      password VARCHAR(255) NOT NULL,
      xp INT DEFAULT 0,
      level INT DEFAULT 1,
      streak INT DEFAULT 0,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )
  `);

  await dbPromise.query(`
    CREATE TABLE IF NOT EXISTS stages (
      id VARCHAR(50) PRIMARY KEY,
      stage_number INT NOT NULL UNIQUE,
      title VARCHAR(100) NOT NULL
    )
  `);

  await dbPromise.query(`
    CREATE TABLE IF NOT EXISTS questions (
      id VARCHAR(20) PRIMARY KEY,
      source_question_id INT NOT NULL UNIQUE,
      stage_id VARCHAR(50) NOT NULL,
      topic VARCHAR(100) NOT NULL,
      difficulty VARCHAR(20) NOT NULL,
      xp_reward INT NOT NULL,
      prompt TEXT NOT NULL,
      option_a TEXT NOT NULL,
      option_b TEXT NOT NULL,
      option_c TEXT NOT NULL,
      option_d TEXT NOT NULL,
      correct_answer_index INT NOT NULL,
      explanation TEXT NOT NULL,
      FOREIGN KEY (stage_id) REFERENCES stages(id)
    )
  `);

  await dbPromise.query(`
    CREATE TABLE IF NOT EXISTS user_progress (
      user_id INT PRIMARY KEY,
      progress_json JSON NOT NULL,
      selected_stage_id VARCHAR(50) DEFAULT 'basics',
      last_active_date DATE NULL,
      updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    )
  `);

  await dbPromise.query(`
    CREATE TABLE IF NOT EXISTS user_answers (
      id INT AUTO_INCREMENT PRIMARY KEY,
      user_id INT NOT NULL,
      question_id VARCHAR(20) NOT NULL,
      selected_index INT NOT NULL,
      is_correct BOOLEAN NOT NULL,
      xp_awarded INT NOT NULL DEFAULT 0,
      answered_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      UNIQUE KEY unique_user_question (user_id, question_id),
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
      FOREIGN KEY (question_id) REFERENCES questions(id)
    )
  `);

  for (const stage of COURSE_STAGES) {
    await dbPromise.query(
      "INSERT INTO stages (id, stage_number, title) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE title = VALUES(title)",
      [stage.id, stage.number, stage.title]
    );
  }

  for (const question of QUESTION_BANK) {
    await dbPromise.query(
      `INSERT INTO questions (
        id, source_question_id, stage_id, topic, difficulty, xp_reward, prompt,
        option_a, option_b, option_c, option_d, correct_answer_index, explanation
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      ON DUPLICATE KEY UPDATE
        stage_id = VALUES(stage_id),
        topic = VALUES(topic),
        difficulty = VALUES(difficulty),
        xp_reward = VALUES(xp_reward),
        prompt = VALUES(prompt),
        option_a = VALUES(option_a),
        option_b = VALUES(option_b),
        option_c = VALUES(option_c),
        option_d = VALUES(option_d),
        correct_answer_index = VALUES(correct_answer_index),
        explanation = VALUES(explanation)`,
      [
        question.id,
        question.sourceQuestionId,
        question.stageId,
        question.topic,
        question.difficulty,
        question.xpReward,
        question.prompt,
        question.options[0],
        question.options[1],
        question.options[2],
        question.options[3],
        question.correctAnswer,
        question.explanation
      ]
    );
  }
}

async function getUserById(userId) {
  const [users] = await dbPromise.query(
    "SELECT id, email, password, xp, level, streak FROM users WHERE id = ? LIMIT 1",
    [userId]
  );

  return users[0] || null;
}

async function getStoredProgress(userId) {
  const [progressRows] = await dbPromise.query(
    "SELECT progress_json, selected_stage_id, last_active_date FROM user_progress WHERE user_id = ? LIMIT 1",
    [userId]
  );

  if (progressRows.length === 0) {
    return null;
  }

  return {
    ...progressRows[0],
    progress_json: parseProgress(progressRows[0].progress_json)
  };
}

async function getScoreFromAnswers(userId) {
  const [rows] = await dbPromise.query(
    "SELECT COALESCE(SUM(xp_awarded), 0) AS total_xp FROM user_answers WHERE user_id = ?",
    [userId]
  );

  return Number(rows[0].total_xp) || 0;
}

async function updateUserScoreFromAnswers(userId) {
  const totalXP = await getScoreFromAnswers(userId);
  const level = calculateLevel(totalXP);

  await dbPromise.query(
    "UPDATE users SET xp = ?, level = ? WHERE id = ?",
    [totalXP, level, userId]
  );

  return { totalXP, level };
}

async function buildProgressForUser(userId) {
  const user = await getUserById(userId);

  if (!user) {
    return null;
  }

  const storedProgress = await getStoredProgress(userId);
  const storedJson = storedProgress ? storedProgress.progress_json || {} : {};
  const score = await updateUserScoreFromAnswers(userId);
  const progress = createDefaultProgress();

  progress.totalXP = score.totalXP;
  progress.xp = score.totalXP;
  progress.level = score.level;
  progress.streak = Number(user.streak) || 0;
  progress.lastActiveDate = formatDateValue(storedProgress && storedProgress.last_active_date);
  progress.currentQuestionByStage = sanitizeCurrentQuestionByStage(storedJson.currentQuestionByStage);
  const practiceState = sanitizePracticeState(storedJson);
  progress.practiceResets = practiceState.practiceResets;
  progress.practiceAnswers = practiceState.practiceAnswers;

  const [answers] = await dbPromise.query(
    `SELECT question_id, selected_index, is_correct, xp_awarded, answered_at
     FROM user_answers
     WHERE user_id = ?
     ORDER BY answered_at`,
    [userId]
  );

  answers.forEach((answer) => {
    const question = getQuestionById(answer.question_id);

    if (!question || !progress.stages[question.stageId]) {
      return;
    }

    const answerState = {
      status: answer.is_correct ? "correct" : "incorrect",
      selectedIndex: Number(answer.selected_index),
      firstAttemptCorrect: Boolean(answer.is_correct),
      xpAwarded: Number(answer.xp_awarded) > 0,
      answeredAt: toIsoString(answer.answered_at)
    };

    if (!shouldHideStoredAnswerForPractice(question, answer, progress.practiceResets)) {
      progress.stages[question.stageId].answeredQuestions[question.id] = answerState;
    }

    if (answerState.xpAwarded && !progress.earnedQuestionIds.includes(question.id)) {
      progress.earnedQuestionIds.push(question.id);
    }
  });

  Object.entries(progress.practiceAnswers).forEach(([stageId, stageAnswers]) => {
    if (!progress.practiceResets[stageId] || !progress.stages[stageId]) {
      return;
    }

    Object.entries(stageAnswers).forEach(([questionId, answerState]) => {
      progress.stages[stageId].answeredQuestions[questionId] = answerState;
    });
  });

  recalculateStageLocks(progress);

  const selectedStageId = storedProgress && storedProgress.selected_stage_id
    ? storedProgress.selected_stage_id
    : storedJson.selectedStageId;

  progress.selectedStageId = getSafeSelectedStageId(selectedStageId, progress);
  progress.selectedStage = getStageById(progress.selectedStageId).number;

  return progress;
}

async function saveProgressSnapshot(userId, progress) {
  const snapshot = {
    ...progress,
    practiceResets: progress.practiceResets || {},
    practiceAnswers: progress.practiceAnswers || {}
  };

  await dbPromise.query(
    `INSERT INTO user_progress (user_id, progress_json, selected_stage_id, last_active_date)
     VALUES (?, ?, ?, ?)
     ON DUPLICATE KEY UPDATE
       progress_json = VALUES(progress_json),
       selected_stage_id = VALUES(selected_stage_id),
       last_active_date = VALUES(last_active_date)`,
    [
      userId,
      JSON.stringify(snapshot),
      progress.selectedStageId || "basics",
      progress.lastActiveDate || null
    ]
  );
}

async function recordDailyActivity(userId) {
  const storedProgress = await getStoredProgress(userId);
  const today = getLocalDateString();
  const yesterday = new Date();
  yesterday.setDate(yesterday.getDate() - 1);

  const lastActiveDate = formatDateValue(storedProgress && storedProgress.last_active_date);
  const [users] = await dbPromise.query(
    "SELECT streak FROM users WHERE id = ? LIMIT 1",
    [userId]
  );
  const currentStreak = Number(users[0] && users[0].streak) || 0;

  let streak = currentStreak;

  if (!lastActiveDate) {
    streak = 1;
  } else if (lastActiveDate === today) {
    streak = currentStreak || 1;
  } else {
    streak = lastActiveDate === getLocalDateString(yesterday)
      ? currentStreak + 1
      : 1;
  }

  await dbPromise.query(
    "UPDATE users SET streak = ? WHERE id = ?",
    [streak, userId]
  );

  const progress = await buildProgressForUser(userId);
  progress.streak = streak;
  progress.lastActiveDate = today;
  await saveProgressSnapshot(userId, progress);

  return progress;
}

function requireApiSession(req, res, next) {
  if (req.session && req.session.userId) {
    return next();
  }

  return res.status(401).json({
    success: false,
    message: "Please log in before continuing."
  });
}

function requirePageSession(req, res, next) {
  if (req.session && req.session.userId) {
    return next();
  }

  return res.redirect("/login");
}

function requireMatchingSessionUser(req, res, next) {
  const requestedUserId = validateUserId(req.params.userId);

  if (!requestedUserId) {
    return res.status(400).json({
      success: false,
      message: "A valid user id is required."
    });
  }

  if (requestedUserId !== req.session.userId) {
    return res.status(403).json({
      success: false,
      message: "You can only access your own progress."
    });
  }

  return next();
}

function sendHtml(fileName) {
  return (req, res) => {
    res.sendFile(path.join(__dirname, fileName));
  };
}

app.get(["/", "/index.html"], sendHtml("index.html"));
app.get(["/login", "/login.html"], sendHtml("login.html"));
app.get(["/path", "/path.html"], requirePageSession, sendHtml("path.html"));
app.get(["/exercise", "/exercise.html"], requirePageSession, sendHtml("exercise.html"));

app.post("/api/register", async (req, res) => {
  const email = String(req.body.email || "").trim().toLowerCase();
  const password = String(req.body.password || "").trim();
  const validationErrors = validateLoginInput(email, password);

  if (validationErrors.length > 0) {
    return res.status(400).json({
      success: false,
      message: validationErrors.join(" ")
    });
  }

  try {
    const [existingUsers] = await dbPromise.query(
      "SELECT id FROM users WHERE email = ? LIMIT 1",
      [email]
    );

    if (existingUsers.length > 0) {
      return res.status(409).json({
        success: false,
        message: "An account with this email already exists. Please log in instead."
      });
    }

    const passwordHash = await bcrypt.hash(password, 10);
    const [insertResult] = await dbPromise.query(
      "INSERT INTO users (email, password, xp, level, streak) VALUES (?, ?, 0, 1, 0)",
      [email, passwordHash]
    );

    req.session.userId = insertResult.insertId;
    const progress = await recordDailyActivity(insertResult.insertId);
    const user = await getUserById(insertResult.insertId);

    return res.status(201).json({
      success: true,
      message: "Account created successfully.",
      user: getPublicUser(user),
      progress
    });
  } catch (error) {
    console.error("Register query failed:", error);
    return res.status(500).json({
      success: false,
      message: "Could not create the account. Please try again later."
    });
  }
});

app.post("/api/login", async (req, res) => {
  const email = String(req.body.email || "").trim().toLowerCase();
  const password = String(req.body.password || "").trim();
  const validationErrors = validateLoginInput(email, password);

  if (validationErrors.length > 0) {
    return res.status(400).json({
      success: false,
      message: validationErrors.join(" ")
    });
  }

  try {
    const [users] = await dbPromise.query(
      "SELECT id, email, password, xp, level, streak FROM users WHERE email = ? LIMIT 1",
      [email]
    );

    if (users.length === 0) {
      return res.status(401).json({
        success: false,
        message: "Incorrect email or password."
      });
    }

    const user = users[0];
    const storedPassword = String(user.password || "");
    const isHashedPassword = passwordHashPattern.test(storedPassword);
    const passwordMatches = isHashedPassword
      ? await bcrypt.compare(password, storedPassword)
      : storedPassword === password;

    if (!passwordMatches) {
      return res.status(401).json({
        success: false,
        message: "Incorrect email or password."
      });
    }

    if (!isHashedPassword) {
      const passwordHash = await bcrypt.hash(password, 10);
      await dbPromise.query(
        "UPDATE users SET password = ? WHERE id = ?",
        [passwordHash, user.id]
      );
    }

    req.session.userId = user.id;
    const progress = await recordDailyActivity(user.id);
    const freshUser = await getUserById(user.id);

    return res.json({
      success: true,
      message: "Login successful.",
      user: getPublicUser(freshUser),
      progress
    });
  } catch (error) {
    console.error("Login query failed:", error);
    return res.status(500).json({
      success: false,
      message: "A server error occurred. Please try again later."
    });
  }
});

app.post("/api/logout", (req, res) => {
  req.session.destroy((error) => {
    if (error) {
      return res.status(500).json({
        success: false,
        message: "Could not log out. Please try again."
      });
    }

    res.clearCookie("connect.sid");
    return res.json({
      success: true,
      message: "Logged out successfully."
    });
  });
});

app.get("/api/me", requireApiSession, async (req, res) => {
  try {
    const user = await getUserById(req.session.userId);

    if (!user) {
      req.session.destroy(() => {});
      return res.status(401).json({
        success: false,
        message: "Please log in before continuing."
      });
    }

    return res.json({
      success: true,
      user: getPublicUser(user)
    });
  } catch (error) {
    console.error("Session user load failed:", error);
    return res.status(500).json({
      success: false,
      message: "Could not check the current session."
    });
  }
});

app.get("/api/questions", async (req, res) => {
  const stageId = typeof req.query.stageId === "string" ? req.query.stageId : "";
  const params = [];
  let sql = `
    SELECT id, source_question_id, stage_id, topic, difficulty, xp_reward, prompt,
           option_a, option_b, option_c, option_d, explanation
    FROM questions
  `;

  if (stageId) {
    sql += " WHERE stage_id = ?";
    params.push(stageId);
  }

  sql += " ORDER BY source_question_id";

  try {
    const [questions] = await dbPromise.query(sql, params);

    return res.json({
      success: true,
      questions: questions.map((question) => ({
        id: question.id,
        sourceQuestionId: question.source_question_id,
        stageId: question.stage_id,
        topic: question.topic,
        difficulty: question.difficulty,
        xpReward: question.xp_reward,
        prompt: question.prompt,
        options: [question.option_a, question.option_b, question.option_c, question.option_d],
        explanation: question.explanation
      }))
    });
  } catch (error) {
    console.error("Questions load failed:", error);
    return res.status(500).json({
      success: false,
      message: "Could not load questions."
    });
  }
});

async function handleGetProgress(req, res) {
  try {
    const progress = await buildProgressForUser(req.session.userId);
    const user = await getUserById(req.session.userId);

    if (!progress || !user) {
      return res.status(404).json({
        success: false,
        message: "User was not found."
      });
    }

    await saveProgressSnapshot(req.session.userId, progress);

    return res.json({
      success: true,
      user: getPublicUser(user),
      progress
    });
  } catch (error) {
    console.error("Progress load failed:", error);
    return res.status(500).json({
      success: false,
      message: "Could not load progress from the server."
    });
  }
}

app.get("/api/progress", requireApiSession, handleGetProgress);
app.get("/api/progress/:userId", requireApiSession, requireMatchingSessionUser, handleGetProgress);

async function handlePutProgress(req, res) {
  try {
    const incomingProgress = req.body.progress && typeof req.body.progress === "object"
      ? req.body.progress
      : {};
    const progress = await buildProgressForUser(req.session.userId);

    if (!progress) {
      return res.status(404).json({
        success: false,
        message: "User was not found."
      });
    }

    progress.currentQuestionByStage = sanitizeCurrentQuestionByStage(incomingProgress.currentQuestionByStage);

    if (typeof incomingProgress.selectedStageId === "string") {
      progress.selectedStageId = getSafeSelectedStageId(incomingProgress.selectedStageId, progress);
      progress.selectedStage = getStageById(progress.selectedStageId).number;
    }

    await saveProgressSnapshot(req.session.userId, progress);

    return res.json({
      success: true,
      message: "Progress saved.",
      progress
    });
  } catch (error) {
    console.error("Progress save failed:", error);
    return res.status(500).json({
      success: false,
      message: "Could not save progress to the server."
    });
  }
}

app.put("/api/progress", requireApiSession, handlePutProgress);
app.put("/api/progress/:userId", requireApiSession, requireMatchingSessionUser, handlePutProgress);

app.post("/api/restart-stage", requireApiSession, async (req, res) => {
  const stageId = typeof req.body.stageId === "string" ? req.body.stageId : "";
  const stage = COURSE_STAGES.find((item) => item.id === stageId);

  if (!stage) {
    return res.status(400).json({
      success: false,
      message: "A valid stage id is required."
    });
  }

  try {
    const progress = await buildProgressForUser(req.session.userId);
    const stageProgress = progress && progress.stages[stage.id];

    if (!progress || !stageProgress || !stageProgress.unlocked) {
      return res.status(403).json({
        success: false,
        message: "This stage is locked. Complete the previous stage first."
      });
    }

    progress.practiceResets = progress.practiceResets || {};
    progress.practiceAnswers = progress.practiceAnswers || {};
    progress.practiceResets[stage.id] = new Date().toISOString();
    progress.practiceAnswers[stage.id] = {};
    progress.stages[stage.id].answeredQuestions = {};
    progress.currentQuestionByStage[stage.id] = 0;
    progress.selectedStageId = stage.id;
    progress.selectedStage = stage.number;
    recalculateStageLocks(progress);

    await saveProgressSnapshot(req.session.userId, progress);

    return res.json({
      success: true,
      message: "Stage restarted for practice.",
      progress
    });
  } catch (error) {
    console.error("Stage restart failed:", error);
    return res.status(500).json({
      success: false,
      message: "Could not restart the stage."
    });
  }
});

app.post("/api/answers", requireApiSession, async (req, res) => {
  const userId = req.session.userId;
  const questionId = String(req.body.questionId || "");
  const selectedIndex = Number(req.body.selectedIndex);
  const question = getQuestionById(questionId);

  if (!question || !Number.isInteger(selectedIndex) || selectedIndex < 0 || selectedIndex > 3) {
    return res.status(400).json({
      success: false,
      message: "A valid question and answer are required."
    });
  }

  try {
    const currentProgress = await buildProgressForUser(userId);
    const stageProgress = currentProgress && currentProgress.stages[question.stageId];

    if (!currentProgress || !stageProgress || !stageProgress.unlocked) {
      return res.status(403).json({
        success: false,
        message: "This stage is locked. Complete the previous stage first."
      });
    }

    await dbPromise.beginTransaction();

    const [existingAnswers] = await dbPromise.query(
      `SELECT selected_index, is_correct, xp_awarded, answered_at
       FROM user_answers
       WHERE user_id = ? AND question_id = ?
       LIMIT 1
       FOR UPDATE`,
      [userId, questionId]
    );

    if (existingAnswers.length > 0) {
      const existing = existingAnswers[0];
      let answerState = {
        status: existing.is_correct ? "correct" : "incorrect",
        selectedIndex: Number(existing.selected_index),
        firstAttemptCorrect: Boolean(existing.is_correct),
        xpAwarded: Number(existing.xp_awarded) > 0,
        answeredAt: toIsoString(existing.answered_at)
      };
      const progress = await buildProgressForUser(userId);

      if (progress.practiceResets && progress.practiceResets[question.stageId]) {
        const practiceCorrect = selectedIndex === question.correctAnswer;

        answerState = {
          status: practiceCorrect ? "correct" : "incorrect",
          selectedIndex,
          firstAttemptCorrect: practiceCorrect,
          xpAwarded: false,
          practice: true,
          answeredAt: new Date().toISOString()
        };

        progress.practiceAnswers = progress.practiceAnswers || {};
        progress.practiceAnswers[question.stageId] = progress.practiceAnswers[question.stageId] || {};
        progress.practiceAnswers[question.stageId][question.id] = answerState;
        progress.stages[question.stageId].answeredQuestions[question.id] = answerState;
        recalculateStageLocks(progress);
      }

      await saveProgressSnapshot(userId, progress);
      await dbPromise.commit();

      return res.json({
        success: true,
        accepted: Boolean(answerState.practice),
        alreadyAnswered: true,
        awarded: false,
        xpAwarded: 0,
        answerState,
        progress
      });
    }

    const isCorrect = selectedIndex === question.correctAnswer;
    const xpAwarded = isCorrect ? question.xpReward : 0;

    await dbPromise.query(
      "INSERT INTO user_answers (user_id, question_id, selected_index, is_correct, xp_awarded) VALUES (?, ?, ?, ?, ?)",
      [userId, questionId, selectedIndex, isCorrect, xpAwarded]
    );

    await updateUserScoreFromAnswers(userId);
    const progress = await buildProgressForUser(userId);
    const answerState = progress.stages[question.stageId].answeredQuestions[question.id];
    await saveProgressSnapshot(userId, progress);
    await dbPromise.commit();

    return res.json({
      success: true,
      accepted: true,
      alreadyAnswered: false,
      awarded: xpAwarded > 0,
      xpAwarded,
      answerState,
      progress
    });
  } catch (error) {
    try {
      await dbPromise.rollback();
    } catch (rollbackError) {
      console.error("Answer rollback failed:", rollbackError);
    }

    if (error && error.code === "ER_DUP_ENTRY") {
      const progress = await buildProgressForUser(userId);
      const answerState = progress.stages[question.stageId].answeredQuestions[question.id];

      return res.json({
        success: true,
        accepted: false,
        alreadyAnswered: true,
        awarded: false,
        xpAwarded: 0,
        answerState,
        progress
      });
    }

    console.error("Answer submission failed:", error);
    return res.status(500).json({
      success: false,
      message: "Could not save the answer."
    });
  }
});

let server;

initializeDatabase()
  .then(() => {
    console.log("Database tables are ready");
    server = app.listen(port, () => {
      console.log(`PyLearn server is running at http://localhost:${port}`);
    });
  })
  .catch((error) => {
    console.error("Database initialization failed:", error);
  });

module.exports = {
  app,
  get server() {
    return server;
  }
};
