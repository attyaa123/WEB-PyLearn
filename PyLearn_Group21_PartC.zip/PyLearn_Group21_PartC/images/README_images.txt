PyLearn Images Folder
=====================

This folder is reserved for image assets if the project is expanded later.

Current project note:
- The current Part C submission uses CSS-based shapes, cards, and color styling instead of external image files.
- This keeps the project lightweight while the app runs through the local Express server.
