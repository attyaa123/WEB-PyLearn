PyLearn - Group 21 - Part C
===========================

Project name:
PyLearn

Group:
Group 21

Project stage:
Part C of the WEB Development Course project - server side.

Overview:
PyLearn is a gamified Python learning platform for beginners and early-stage university students.
Part B was a client-side project with simulated login and localStorage progress.
Part C adds a Node.js/Express server, MySQL database, server routes, persistent users,
server-side answer saving, and server-controlled XP/progress rules.

Main pages:
1. index.html
   Home page that introduces PyLearn.

2. login.html
   Login and registration form connected to server API routes.

3. path.html
   Protected learning path page with XP, level, streak, progress bar, and stage cards.

4. exercise.html
   Protected multiple-choice exercise page with answer submission to the server.

Server and database:
- server.js - Express server, API routes, sessions, protected routes, DB initialization.
- db.js - MySQL connection.
- database_schema.sql - Manual SQL setup script.
- courseData.js - Loads and maps the 30 Python quiz questions for DB seeding.
- python_quiz_questions.json - Source question dataset.

Database tables:
- users - registered users, bcrypt password hashes, XP, level, streak.
- stages - learning stages.
- questions - 30 multiple-choice Python questions.
- user_answers - first submitted answer per user/question.
- user_progress - selected stage, current question indexes, and saved progress snapshot.

Important behavior:
- Login and registration are handled by the server.
- Passwords are stored as bcrypt hashes.
- Protected course pages require a server session.
- XP is calculated by the server from saved answers.
- The first submitted answer is final for scoring.
- Re-submitting the same question cannot award XP again.
- Locked stages cannot be answered through the API.
- The browser still keeps a local UI copy for smooth rendering, but the database is the source of truth.

API routes:
- POST /api/register
- POST /api/login
- POST /api/logout
- GET /api/me
- GET /api/questions
- GET /api/progress
- PUT /api/progress
- GET /api/progress/:userId
- PUT /api/progress/:userId
- POST /api/restart-stage
- POST /api/answers

How to run:
1. Install Node dependencies:

   npm install

2. Make sure MySQL is running.

   Optional database environment variables:

   DB_HOST=localhost
   DB_USER=root
   DB_PASSWORD=your_mysql_password
   DB_NAME=pylearn_db

3. Either run the SQL file manually:

   mysql -u root < database_schema.sql

   Or let server.js create the database/tables automatically on startup.

4. Start the server:

   npm start

5. Open the app in the browser:

   http://localhost:3000

Useful checks:

   npm run check

Project structure:

PyLearn_Group21_PartC/
|
|-- index.html
|-- login.html
|-- path.html
|-- exercise.html
|-- server.js
|-- db.js
|-- courseData.js
|-- database_schema.sql
|-- python_quiz_questions.json
|-- package.json
|-- README.txt
|
|-- css/
|   |-- style.css
|
|-- js/
|   |-- app.js
|   |-- login.js
|   |-- path.js
|   |-- exercise.js
|
|-- images/
|   |-- README_images.txt
