document.addEventListener("DOMContentLoaded", async function () {
    if (await PyLearnApp.redirectIfLoggedIn()) {
        return;
    }

    const loginForm = document.getElementById("loginForm");
    const registerBtn = document.getElementById("registerBtn");
    const emailInput = document.getElementById("email");
    const passwordInput = document.getElementById("password");
    const loginMessage = document.getElementById("loginMessage");

    function showMessage(text, type) {
        loginMessage.textContent = text;
        loginMessage.className = `message ${type} show`;
    }

    function isValidEmail(email) {
        return /^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$/.test(email);
    }

    function setSubmitting(isSubmitting, mode) {
        const submitButton = loginForm.querySelector('button[type="submit"]');

        submitButton.disabled = isSubmitting;
        registerBtn.disabled = isSubmitting;
        submitButton.textContent = isSubmitting && mode === "login" ? "Logging in..." : "Log In";
        registerBtn.textContent = isSubmitting && mode === "register" ? "Creating account..." : "Create Account";
    }

    function validateCredentials() {
        const email = emailInput.value.trim();
        const password = passwordInput.value.trim();
        const errors = [];

        if (!email) {
            errors.push("Email is required.");
        } else if (!/^[\x00-\x7F]+$/.test(email)) {
            errors.push("Email must use English letters, numbers, and standard symbols only.");
        } else if (!isValidEmail(email)) {
            errors.push("Please enter a valid email address.");
        }

        if (!password) {
            errors.push("Password is required.");
        } else if (password.length < 6) {
            errors.push("Password must be at least 6 characters long.");
        }

        if (errors.length > 0) {
            showMessage(errors.join(" "), "error");
            return null;
        }

        return { email, password };
    }

    async function startSession(result, successMessage) {
        const user = {
            id: result.user.id,
            email: result.user.email,
            name: result.user.name || PyLearnApp.getDisplayName(result.user),
            loginTime: new Date().toISOString()
        };

        PyLearnApp.setUser(user);

        let progress = result.progress;

        try {
            progress = progress || await PyLearnApp.loadProgressFromServer();
        } catch (error) {
            progress = PyLearnApp.ensureProgress();
        }

        PyLearnApp.saveProgress(progress);

        showMessage(successMessage(user), "success");

        loginForm.reset();

        window.setTimeout(function () {
            window.location.href = "path.html";
        }, 900);
    }

    async function submitAuthRequest(endpoint, credentials, mode) {
        setSubmitting(true, mode);

        try {
            const response = await fetch(endpoint, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify(credentials)
            });
            const result = await response.json();

            if (!response.ok || !result.success) {
                showMessage(result.message || "Login failed. Please try again.", "error");
                return;
            }

            await startSession(result, function (user) {
                return mode === "register"
                    ? `Welcome, ${user.name}! Your account was created successfully. Redirecting to the learning path...`
                    : `Welcome, ${user.name}! Your progress was loaded successfully. Redirecting to the learning path...`;
            });
        } catch (error) {
            showMessage("Cannot reach the server right now. Please make sure it is running and try again.", "error");
        } finally {
            setSubmitting(false, mode);
        }
    }

    loginForm.addEventListener("submit", async function (event) {
        event.preventDefault();

        const credentials = validateCredentials();

        if (!credentials) {
            return;
        }

        await submitAuthRequest("/api/login", credentials, "login");
    });

    registerBtn.addEventListener("click", async function () {
        const credentials = validateCredentials();

        if (!credentials) {
            return;
        }

        await submitAuthRequest("/api/register", credentials, "register");
    });
});
