document.addEventListener("DOMContentLoaded", async function () {
    if (!(await PyLearnApp.requireLogin())) {
        return;
    }

    let progress = PyLearnApp.getProgress();

    try {
        progress = await PyLearnApp.loadProgressFromServer();
    } catch (error) {
        console.warn(error.message);
    }

    let selectedStageId = progress.selectedStageId;
    let stageStats = PyLearnApp.getStageStats(selectedStageId, progress);

    if (!stageStats.hasQuestions || !stageStats.unlocked) {
        selectedStageId = PyLearnApp.getFirstUnlockedPlayableStageId(progress);
        progress = PyLearnApp.setSelectedStage(selectedStageId);
        stageStats = PyLearnApp.getStageStats(selectedStageId, progress);
    }

    let stageQuestions = PyLearnApp.getQuestionsForStage(selectedStageId);
    let currentQuestionIndex = PyLearnApp.getCurrentQuestionIndex(selectedStageId);

    const stageName = document.getElementById("stageName");
    const questionCounter = document.getElementById("questionCounter");
    const questionTopic = document.getElementById("questionTopic");
    const questionIntro = document.getElementById("questionIntro");
    const difficultyBadge = document.getElementById("difficultyBadge");
    const xpRewardBadge = document.getElementById("xpRewardBadge");
    const questionText = document.getElementById("questionText");
    const optionsContainer = document.getElementById("optionsContainer");
    const practiceNote = document.getElementById("practiceNote");
    const quizForm = document.getElementById("quizForm");
    const submitAnswerBtn = document.getElementById("submitAnswerBtn");
    const previousQuestionBtn = document.getElementById("previousQuestionBtn");
    const nextQuestionBtn = document.getElementById("nextQuestionBtn");
    const restartStageBtn = document.getElementById("restartStageBtn");
    const feedbackBox = document.getElementById("feedbackBox");
    const feedbackTitle = document.getElementById("feedbackTitle");
    const feedbackText = document.getElementById("feedbackText");
    const xpSidebar = document.getElementById("xpSidebar");
    const levelSidebar = document.getElementById("levelSidebar");
    const streakSidebar = document.getElementById("streakSidebar");
    const completionSidebar = document.getElementById("completionSidebar");
    const questionTracker = document.getElementById("questionTracker");

    function getCurrentQuestion() {
        return stageQuestions[currentQuestionIndex];
    }

    function updateProgressSnapshot() {
        progress = PyLearnApp.getProgress();
        stageStats = PyLearnApp.getStageStats(selectedStageId, progress);
        stageQuestions = PyLearnApp.getQuestionsForStage(selectedStageId);
    }

    function showFeedback(title, type, text) {
        feedbackTitle.textContent = title;
        feedbackText.textContent = text;
        feedbackBox.className = `feedback-box ${type} show`;
    }

    function updateSidebar() {
        updateProgressSnapshot();
        xpSidebar.textContent = progress.totalXP;
        levelSidebar.textContent = progress.level;
        streakSidebar.textContent = progress.streak;
        completionSidebar.textContent = `${stageStats.answered}/${stageStats.total}`;
    }

    function renderTracker() {
        questionTracker.innerHTML = stageQuestions.map(function (question, index) {
            const answerState = PyLearnApp.getQuestionAnswerState(question.id, progress);
            const stateClass = answerState.status || "unanswered";
            const activeClass = index === currentQuestionIndex ? "active" : "";

            return `
                <button class="tracker-button ${stateClass} ${activeClass}" type="button" data-question-index="${index}" aria-label="Go to question ${index + 1}">
                    ${index + 1}
                </button>
            `;
        }).join("");
    }

    function renderSavedFeedback(question, answerState) {
        if (answerState.status === "correct") {
            const savedXpMessage = answerState.xpAwarded
                ? "You earned XP on the first submission for this question."
                : "This is correct practice, but the XP for this question was already earned before.";

            showFeedback(
                "Correct answer saved.",
                "success",
                `${question.explanation} ${savedXpMessage}`
            );
            return;
        }

        if (answerState.status === "incorrect") {
            showFeedback(
                "First answer was incorrect.",
                "error",
                `${question.explanation} This question is locked for scoring, so changing it now will not award XP.`
            );
            return;
        }

        showFeedback(
            "Ready when you are",
            "info",
            "Select one option and submit your answer to see immediate feedback and explanations."
        );
    }

    function renderOptions(question, answerState) {
        const answered = answerState.status !== "unanswered";

        optionsContainer.innerHTML = question.options.map(function (option, index) {
            const optionLetter = String.fromCharCode(65 + index);
            const checked = answered && answerState.selectedIndex === index ? "checked" : "";
            const disabled = answered ? "disabled" : "";
            const selectedClass = answered && answerState.selectedIndex === index ? "selected-answer" : "";
            const disabledClass = answered ? "disabled-answer" : "";
            let correctnessClass = "";

            if (answered && index === question.correctAnswer) {
                correctnessClass = "correct";
            } else if (answered && answerState.selectedIndex === index) {
                correctnessClass = "incorrect";
            }

            return `
                <label class="option-label ${selectedClass} ${correctnessClass} ${disabledClass}">
                    <input type="radio" name="answer" value="${index}" ${checked} ${disabled}>
                    <span class="option-marker">${optionLetter}</span>
                    <span>${option}</span>
                </label>
            `;
        }).join("");
    }

    function escapeHtml(value) {
        return String(value)
            .replace(/&/g, "&amp;")
            .replace(/</g, "&lt;")
            .replace(/>/g, "&gt;")
            .replace(/"/g, "&quot;")
            .replace(/'/g, "&#039;");
    }

    function highlightPython(code) {
        const keywords = new Set([
            "and", "as", "break", "class", "continue", "def", "elif", "else",
            "except", "False", "finally", "for", "if", "in", "is", "lambda",
            "None", "not", "or", "return", "True", "try", "while", "with"
        ]);
        const builtins = new Set([
            "bool", "dict", "filter", "int", "len", "list", "map", "print",
            "range", "set", "str", "sum", "tuple", "type"
        ]);
        let highlightedCode = "";
        let index = 0;
        let expectFunctionName = false;

        while (index < code.length) {
            const character = code[index];

            if (character === "#") {
                let end = index;

                while (end < code.length && code[end] !== "\n") {
                    end += 1;
                }

                highlightedCode += `<span class="code-comment">${escapeHtml(code.slice(index, end))}</span>`;
                index = end;
                continue;
            }

            if (character === "\"" || character === "'") {
                const quote = character;
                let end = index + 1;

                while (end < code.length) {
                    if (code[end] === "\\" && end + 1 < code.length) {
                        end += 2;
                        continue;
                    }

                    if (code[end] === quote) {
                        end += 1;
                        break;
                    }

                    end += 1;
                }

                highlightedCode += `<span class="code-string">${escapeHtml(code.slice(index, end))}</span>`;
                index = end;
                continue;
            }

            if (/[0-9]/.test(character)) {
                let end = index + 1;

                while (end < code.length && /[0-9.]/.test(code[end])) {
                    end += 1;
                }

                highlightedCode += `<span class="code-number">${escapeHtml(code.slice(index, end))}</span>`;
                index = end;
                continue;
            }

            if (/[A-Za-z_]/.test(character)) {
                let end = index + 1;

                while (end < code.length && /[A-Za-z0-9_]/.test(code[end])) {
                    end += 1;
                }

                const word = code.slice(index, end);

                if (expectFunctionName) {
                    highlightedCode += `<span class="code-function">${escapeHtml(word)}</span>`;
                    expectFunctionName = false;
                } else if (keywords.has(word)) {
                    highlightedCode += `<span class="code-keyword">${escapeHtml(word)}</span>`;
                    expectFunctionName = word === "def";
                } else if (builtins.has(word)) {
                    highlightedCode += `<span class="code-builtin">${escapeHtml(word)}</span>`;
                } else {
                    highlightedCode += escapeHtml(word);
                }

                index = end;
                continue;
            }

            highlightedCode += escapeHtml(character);
            index += 1;
        }

        return highlightedCode;
    }

    function renderQuestionPrompt(prompt) {
        const promptParts = prompt.split("\n\n");
        const promptTitle = document.createElement("p");

        questionText.innerHTML = "";
        promptTitle.className = "question-title";
        promptTitle.textContent = promptParts[0];
        questionText.appendChild(promptTitle);

        if (promptParts.length <= 1) {
            return;
        }

        const codeBlock = document.createElement("pre");
        const codeElement = document.createElement("code");

        codeBlock.className = "question-code";
        codeElement.innerHTML = highlightPython(promptParts.slice(1).join("\n\n"));
        codeBlock.appendChild(codeElement);
        questionText.appendChild(codeBlock);
    }

    function loadQuestion() {
        updateProgressSnapshot();

        const currentStage = PyLearnApp.getStageById(selectedStageId);
        const currentQuestion = getCurrentQuestion();

        if (!currentQuestion) {
            renderQuestionPrompt("No questions are available for this stage yet.");
            practiceNote.textContent = "Return to the learning path and choose an unlocked stage.";
            optionsContainer.innerHTML = "";
            submitAnswerBtn.disabled = true;
            previousQuestionBtn.disabled = true;
            nextQuestionBtn.disabled = true;
            renderTracker();
            return;
        }

        const answerState = PyLearnApp.getQuestionAnswerState(currentQuestion.id, progress);
        const answered = answerState.status !== "unanswered";

        stageName.textContent = currentStage.title;
        questionCounter.textContent = `Question ${currentQuestionIndex + 1} of ${stageQuestions.length}`;
        questionTopic.textContent = currentQuestion.topic;
        questionIntro.textContent = currentQuestion.intro;
        difficultyBadge.textContent = currentQuestion.difficulty;
        difficultyBadge.className = `difficulty-badge ${currentQuestion.difficulty.toLowerCase()}`;
        xpRewardBadge.textContent = `+${currentQuestion.xpReward} XP`;
        renderQuestionPrompt(currentQuestion.prompt);

        renderOptions(currentQuestion, answerState);

        practiceNote.textContent = answered
            ? "This question was already submitted. The saved first answer is shown for review."
            : "Only your first submitted answer counts for XP, so choose carefully.";

        submitAnswerBtn.disabled = answered;
        previousQuestionBtn.disabled = currentQuestionIndex === 0;
        nextQuestionBtn.disabled = currentQuestionIndex === stageQuestions.length - 1;

        PyLearnApp.setCurrentQuestionIndex(selectedStageId, currentQuestionIndex);
        renderTracker();
        renderSavedFeedback(currentQuestion, answerState);
        updateSidebar();
    }

    function validateAnswer() {
        const selectedAnswer = document.querySelector('input[name="answer"]:checked');

        if (!selectedAnswer) {
            showFeedback(
                "Please select an answer before submitting.",
                "error",
                "Choose one of the four options and then submit your answer."
            );
            return null;
        }

        return Number(selectedAnswer.value);
    }

    async function handleSubmit(event) {
        event.preventDefault();

        const currentQuestion = getCurrentQuestion();
        const selectedAnswerIndex = validateAnswer();

        if (!currentQuestion || selectedAnswerIndex === null) {
            return;
        }

        let result;

        submitAnswerBtn.disabled = true;

        try {
            result = await PyLearnApp.submitQuestionAnswerToServer(currentQuestion.id, selectedAnswerIndex);
        } catch (error) {
            submitAnswerBtn.disabled = false;
            showFeedback(
                "Could not save your answer.",
                "error",
                error.message || "Please check that the server is running and try again."
            );
            return;
        }

        let feedbackTitleValue;
        let feedbackTypeValue;
        let feedbackTextValue;

        if (result.answerState.status === "correct") {
            const xpMessage = result.awarded
                ? `You earned ${currentQuestion.xpReward} XP.`
                : "No extra XP was awarded because this question was already answered.";

            feedbackTitleValue = "Correct! Great job.";
            feedbackTypeValue = "success";
            feedbackTextValue = `${currentQuestion.explanation} ${xpMessage}`;
        } else {
            feedbackTitleValue = "Not quite yet, but you are improving.";
            feedbackTypeValue = "error";
            feedbackTextValue = `${currentQuestion.explanation} This first answer is saved, so this question will not award XP later.`;
        }

        loadQuestion();
        showFeedback(feedbackTitleValue, feedbackTypeValue, feedbackTextValue);
    }

    function goToQuestion(index) {
        currentQuestionIndex = Math.max(0, Math.min(index, stageQuestions.length - 1));
        PyLearnApp.setCurrentQuestionIndex(selectedStageId, currentQuestionIndex);
        loadQuestion();
    }

    async function restartCurrentStage() {
        restartStageBtn.disabled = true;

        try {
            progress = await PyLearnApp.restartStageOnServer(selectedStageId);
            currentQuestionIndex = 0;
            PyLearnApp.setCurrentQuestionIndex(selectedStageId, currentQuestionIndex);
            loadQuestion();
            showFeedback(
                "Stage restarted for practice.",
                "info",
                "Your visible answers for this stage were cleared, but already earned XP cannot be earned again."
            );
        } catch (error) {
            showFeedback(
                "Could not restart the stage.",
                "error",
                error.message || "Please check that the server is running and try again."
            );
        } finally {
            restartStageBtn.disabled = false;
        }
    }

    quizForm.addEventListener("submit", handleSubmit);

    previousQuestionBtn.addEventListener("click", function () {
        goToQuestion(currentQuestionIndex - 1);
    });

    nextQuestionBtn.addEventListener("click", function () {
        goToQuestion(currentQuestionIndex + 1);
    });

    restartStageBtn.addEventListener("click", restartCurrentStage);

    questionTracker.addEventListener("click", function (event) {
        const trackerButton = event.target.closest(".tracker-button");

        if (!trackerButton) {
            return;
        }

        goToQuestion(Number(trackerButton.dataset.questionIndex));
    });

    loadQuestion();
});
